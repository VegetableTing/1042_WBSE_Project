﻿Gloss BOOTSTRAP FASHION BLOG TEMPLATE



== BRIEF INFORMATION ==

Theme URI: 	http://demo.themesrefinery.net/gloss/
Author: 	Rehman Ali
Author URI:     http://www.themesrefinery.net/
Tags: 		black, red, white,toggle responsive navigation,Lightbox responsive gallery,animated social icons,responsive slider,different options of page with sidebar and without sidebar.
License: 	GNU General Public License, Version 3 (or newer)


== DESCRIPTION ==

We think that every template ought to facilitate creative writing, not delay it. They also think that each site ought to have the chance to be distinctive. Since the template beginning, they have received limitless suggestions & requests on features that matter. They listened, & they delivered. 

Here's a template that is packed filled with features that you require, yet far from being overwhelming. Here's a template that is simple to make use of for beginners, yet well documented & powerful to be endlessly customisable to users with even only moderate technical skills. Here's a template that is available in over 30 languages & is backed with active community support, where questions, ideas & suggestions are always welcomed. 

& best of all, here's a template that is free. Here's a theme that is yours to make it special.



